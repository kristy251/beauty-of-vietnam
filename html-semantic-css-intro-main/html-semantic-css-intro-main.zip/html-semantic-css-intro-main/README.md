# html semantic / css intro
 This example is showing basic HTML semantic structure and how to add CSS to your website

Check it out at: https://lange-lange.github.io/html-semantic-css-intro/index.html

To download the code:

1. Select the green button that says Code >
2. Downdown menu > Select Download Zip
3. Unzip to your folder
4. Open your coding editor of choice
5. File > Open Folder
6. Check it out! Reverse engineer, try snippets in your code.
